

README for sensor to Flash

Description: A PIR sensor, hooked to Arduino, send serial messages to Processing which then writes to a txt file and is read by FLash.

Created by: Owen Mundy <owenmundy.com> 2009 


1. Unzip serial_reader.zip and place folder in Processing sketches folder
2. Setup your Arduino and PIR sensor according to the diagram at: http://www.ladyada.net/learn/sensors/pir.html
3. Upload sensor_pir_arduino.pde sketch to Arduino
4. Run sensor_to_flash.pde sketch
5. Run sensor_to_flash.swf


Arduino sketch by Lady Ada: http://www.ladyada.net/learn/sensors/pir.html
Processing sketch by Tom Igoe (Making Things Talk)
Concept, edits to Processing Sketch, and FLash file by Owen Mundy <owenmundy.com>
